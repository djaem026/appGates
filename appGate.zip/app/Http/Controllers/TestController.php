<?php

namespace App\Http\Controllers;


class TestController extends Controller
{
    protected $mc, $exam, $student, $user;
    public function __construct()
    {

    }

    public function index()
    {

    }

}
